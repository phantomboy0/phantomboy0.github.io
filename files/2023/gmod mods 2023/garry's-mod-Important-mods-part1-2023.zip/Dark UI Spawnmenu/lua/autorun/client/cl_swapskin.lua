
local cl_swapskin_darkui_enabled = CreateClientConVar("cl_swapskin_darkui_enabled", "1", true, false)
local cl_swapskin_darkui_transparent = CreateClientConVar("cl_swapskin_darkui_transparent", "0", true, false)

-- credit: Monk
local function SetGlobalSkin(skinName)
	for k,v in pairs(debug.getregistry()) do
		if ispanel(v) and v.GetSkin and v.SetSkin then
			v:SetSkin(skinName)
			local CurSkin = skinName
		end
	end
end
--

hook.Add( "SpawnMenuOpen", "UpdateSpawnMenu", function()
	if ( cl_swapskin_darkui_enabled:GetBool() == true ) then
		
		if( cl_swapskin_darkui_transparent:GetBool() == true ) then
			SetGlobalSkin( "CISKINT" )
		else
			SetGlobalSkin( "CISKIN" )
		end
	else
		SetGlobalSkin( "Default" )
	end
end)

hook.Add("PopulateToolMenu", "SkinSwitch", function()

	spawnmenu.AddToolMenuOption("Utilities",
		"User",
		"Spawnmenuadjuster",
		"Spawnmenu Adjuster",    "",    "",
		function(pnl)
			pnl:AddControl("Header", {
				Description = "Adjust how your Spawnmenu looks!"
			})

			pnl:AddControl("CheckBox", {
				Label = "Dark UI",
				Command = "cl_swapskin_darkui_enabled",
			})
			pnl:ControlHelp("If Disabled, will make you blind again")

			pnl:AddControl("CheckBox", {
				Label = "Transparent Spawnmenu",
				Command = "cl_swapskin_darkui_transparent",
			})
			pnl:ControlHelp("Will toggle transparency for the spawnmenu background.")

			pnl:AddControl("Header", {
				Description = "NOTE: Some elements may not update properly untill you rejoin your session"
			})

		end
	)
end)