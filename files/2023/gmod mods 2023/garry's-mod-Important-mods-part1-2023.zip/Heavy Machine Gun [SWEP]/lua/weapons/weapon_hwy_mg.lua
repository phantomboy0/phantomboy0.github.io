if CLIENT then
SWEP.WepSelectIcon		= surface.GetTextureID("HUD/swepicons/weapon_hwy_mg/icon") 
SWEP.DrawWeaponInfoBox = false
SWEP.BounceWeaponIcon = false

killicon.Add("weapon_hwy_mg", "HUD/swepicons/weapon_hwy_mg/icon", Color( 255, 255, 255, 255 ) )
end

SWEP.PrintName = "XM214 Microgun"
SWEP.Category = "Half-Life"
SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 90
SWEP.ViewModel = "models/weapons/v_hwy_mg.mdl"
SWEP.WorldModel = "models/weapons/w_hwy_mg.mdl"
SWEP.ViewModelFlip = false
SWEP.BobScale = 1
SWEP.SwayScale = 1

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Weight = 2
SWEP.Slot = 2
SWEP.SlotPos = 0

SWEP.UseHands = false
SWEP.HoldType = "shotgun"
SWEP.DrawCrosshair = true
SWEP.DrawAmmo = true
SWEP.CSMuzzleFlashes = 1
SWEP.Base = "weapon_base"

SWEP.Idle = 0
SWEP.IdleTimer = CurTime()

SWEP.Primary.Sound = Sound( "" )
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 255
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "smg1"
SWEP.Primary.Damage = 17
SWEP.Primary.Spread = 0.15
SWEP.Primary.TakeAmmo = 1
SWEP.Primary.NumberofShots = 1
SWEP.Primary.Delay = 0.03
SWEP.Primary.Force = 20

SWEP.Secondary.Sound = Sound( "" )
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.MaxAmmo = -1
SWEP.Secondary.Automatic = true
SWEP.Secondary.Ammo = "none"
SWEP.Secondary.TakeAmmo = 0
SWEP.Secondary.Delay = 1
SWEP.Secondary.Force = 1250

function SWEP:SetupDataTables()
	self:NetworkVar("Bool", 0, "Windup")
end

function SWEP:Initialize()
	self:SetWeaponHoldType( self.HoldType )
	self:SetHoldType( self.HoldType )
	
	if SERVER then
		self:SetWindup(false)
	end
	self.Idle = 0
	self.IdleTimer = CurTime() + 1
end

function SWEP:Deploy()
	self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
	
	self:SetNextPrimaryFire( CurTime() + 1.5 )
	self:SetNextSecondaryFire( CurTime() + 1.5 )
	self.Idle = 0
	self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
	return true
end

function SWEP:Holster()
	if self:GetWindup() then return false end
	self.Idle = 0
	self.IdleTimer = CurTime()
	return true
end

function SWEP:OnRemove()
	self:Holster()
	return true
end

function SWEP:OnDrop()
	self:Holster()
	return true
end

function SWEP:PrimaryAttack()
	if self:Ammo1() <= 0 then
		if self:GetWindup() then
			local vm = self.Owner:GetViewModel()
			vm:SendViewModelMatchingSequence(vm:LookupSequence("spindown"))
		end
		self:SetWindup(false)
		return
	end
	
	if !self:GetWindup() then
		if timer.TimeLeft( "maxusedelay"..self:EntIndex() ) == nil then
			self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
			self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
			timer.Simple(1, function() if IsValid(self) then
				self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
				self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
				if !self:GetWindup() and self.Owner:KeyDown(IN_ATTACK) then
					self:SetWindup(true)
					local vm = self.Owner:GetViewModel()
					vm:SendViewModelMatchingSequence(vm:LookupSequence("spinfire"))
				end
			end
			end)
		timer.Create( "maxusedelay"..self:EntIndex(), 1, 1, function() end )	
		end
	end

	if SERVER then
		if (self.Owner:KeyPressed(IN_ATTACK) || !self.Sound) then
			self.Owner:EmitSound("weapons/hwy_mg/hw_spinup.wav", 80, 100)
			local vm = self.Owner:GetViewModel()
			vm:SendViewModelMatchingSequence(vm:LookupSequence("spinup"))
			self.Idle = 0
			self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
			self.Sound = CreateSound(self.Owner, Sound("weapons/hwy_mg/hw_spin.wav"))
		end
		
		if (self:Ammo1() > 0) then
			if (self.Sound) then
				self.Sound:PlayEx(1, 100)
			end
		end
	end
	
	if self:GetWindup() then
		local bullet = {}
		bullet.Num = self.Primary.NumberofShots
		bullet.Src = self.Owner:GetShootPos()
		bullet.Dir = self.Owner:GetAimVector()
		bullet.Spread = Vector( 1 * self.Primary.Spread, 1 * self.Primary.Spread, 0 )
		bullet.Tracer = 1
		bullet.Force = self.Primary.Force
		bullet.Damage = self.Primary.Damage
		bullet.AmmoType = self.Primary.Ammo
		bullet.HullSize = 2
		bullet.Callback = function(attacker, trace, dmginfo)
			dmginfo:SetDamageType(DMG_BULLET)
		end
	
		self.Owner:FireBullets( bullet )
		self.Owner:EmitSound("weapons/hwy_mg/hw_shoot"..math.random(2,3)..".wav", 80, 100, 0.3)
		
		local shelleffect = EffectData()
		shelleffect:SetEntity(self)
		shelleffect:SetOrigin(self.Owner:GetShootPos() + self:GetUp()*-18)
		shelleffect:SetAngles(self.Owner:EyeAngles() + Angle(math.random(-40,-50),math.random(-80,-100),math.random(-10,10)))
		util.Effect( "RifleShellEject", shelleffect, true, true )
		
		self:TakePrimaryAmmo(1)
		self.Owner:ViewPunch(Angle(math.random(-1,1),math.random(-1,1),math.random(-1,1))/2)
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
		self.Owner:MuzzleFlash()
		self.Owner:SetVelocity(self.Owner:GetAimVector()*-15)
		
		self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
		self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
	end
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
end

function SWEP:PlayCloseSound()
	self.Owner:EmitSound("weapons/hwy_mg/hw_spindown.wav", 80, 100, 0.3)
end

function SWEP:Think()
	if self.Idle == 0 and self.IdleTimer <= CurTime() then
		if SERVER then
			local vm = self.Owner:GetViewModel()
			vm:SendViewModelMatchingSequence(vm:LookupSequence("gentleidle"))
		end
		self.Idle = 1
	end
	
	if (self.Sound && self.Sound:IsPlaying() && self:Ammo1() < 1) then
		self.Sound:Stop()
		self:PlayCloseSound()
	end
	
	--if self:Ammo1() <= 0 then return end
	
	if (self.Owner:KeyReleased(IN_ATTACK) || (!self.Owner:KeyDown(IN_ATTACK) && self.Sound)) then
		if self:GetWindup() then
			local vm = self.Owner:GetViewModel()
			vm:SendViewModelMatchingSequence(vm:LookupSequence("spindown"))
		
			self:SetNextPrimaryFire(CurTime() + self:SequenceDuration())
			self:SetNextSecondaryFire(CurTime() + self:SequenceDuration())
		end
		self:SetWindup(false)

		if (self.Sound) then
			self.Sound:Stop()
			self.Sound = nil
			if (self:Ammo1() > 0) then
				self:PlayCloseSound()
				if (!game.SinglePlayer()) then
					self:CallOnClient("PlayCloseSound", "")
				end
			end
		end
		
		self.Idle = 0
		self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
	end
	
	--[[if( self.Owner:KeyDown( IN_ATTACK ) ) then
		if self:GetWindup() then
			self.Weapon:SendWeaponAnim( ACT_VM_SPIN )
		end
	elseif ( self.Owner:KeyReleased ( IN_ATTACK ) ) then
		self.Weapon:EmitSound( "tfc/weapons/mgspindown.wav" )
		self.Weapon:SendWeaponAnim( ACT_VM_SPINDOWN )
	end]]
end

if CLIENT then
	local WorldModel = ClientsideModel(SWEP.WorldModel)

	-- Settings...
	--WorldModel:SetSkin(1)
	WorldModel:SetNoDraw(true)

	function SWEP:DrawWorldModel()
		--self:Drawspiral()
		--self.Weapon:DrawModel()
		local _Owner = self:GetOwner()

		if (IsValid(_Owner)) then
            -- Specify a good position
			local offsetVec = Vector(25, -4, 6)
			local offsetAng = Angle(130, 90, -5)
			
			local boneid = _Owner:LookupBone("ValveBiped.Bip01_R_Hand") -- Right Hand
			if !boneid then return end

			local matrix = _Owner:GetBoneMatrix(boneid)
			if !matrix then return end

			local newPos, newAng = LocalToWorld(offsetVec, offsetAng, matrix:GetTranslation(), matrix:GetAngles())

			WorldModel:SetPos(newPos)
			WorldModel:SetAngles(newAng)

            WorldModel:SetupBones()
		else
			WorldModel:SetPos(self:GetPos())
			WorldModel:SetAngles(self:GetAngles())
		end
		WorldModel:DrawModel()
	end
end