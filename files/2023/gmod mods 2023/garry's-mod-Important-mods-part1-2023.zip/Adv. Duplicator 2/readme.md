# Advanced Duplicator 2

Advanced Duplicator 2 is a [Garry's Mod][] addon which implements a tool similar to the Duplicator, but with many added features. It is a fork of (and not a direct successor to, despite the name) [Advanced Duplicator][].

# Installation

Currently, this version of AdvDupe2 isn't available on the Steam Workshop. The best way to get this addon is to clone this repository into your `addons` folder:

    cd "%programfiles(x86)%/Steam/SteamApps/common/GarrysMod/garrysmod/addons"
    git clone https://github.com/wiremod/advdupe2.git advdupe2

# License

Copyright 2014 Wire Team

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.

[Garry's Mod]: <http://garrysmod.com/>
[Advanced Duplicator]: <https://github.com/wiremod/advduplicator>
