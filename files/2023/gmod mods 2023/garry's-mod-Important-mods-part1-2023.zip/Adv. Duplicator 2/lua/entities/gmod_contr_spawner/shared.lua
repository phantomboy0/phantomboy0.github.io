ENT.Type 			= "anim"
ENT.Base			= WireLib and "base_wire_entity" or "base_gmodentity"
ENT.PrintName		= "Contraption Spawner"
ENT.Author			= "TB"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
